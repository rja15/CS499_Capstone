/**
 * @author raymondagosto_snhu
 * raymond.agosto1@snhu.edu
 * CS499 Capstone
 * 
 */

//import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


public class TEST {

	public TEST() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		Player p1 = new Player("Head",false,false,0,1);
//		System.out.println(p1.getInventory().get("Head").getCoordY());
		System.out.println(p1.getInventory().get("Head"));
		
		Coordinate c1 = new Coordinate(1,2);
		System.out.println(c1.getCoordX());
		
//		Coordinate c2 = new Coordinate(2,0);
		Item i2 = new Item("Right Arm",false,false);
		Player p2 = new Player(i2.getItemName(),i2);
		System.out.println(p2.getInventory().get("Right Arm").getItemName());
		
		System.out.println(p2.getInventory().get("Right Arm").getItemLocation());
		p2.getInventory().get("Right Arm").setItemLocation(c1);
		System.out.println(p2.getInventory().get("Right Arm").getItemLocation().getCoordX());

		if(c1 == p2.getInventory().get("Right Arm").getItemLocation())
		{
			System.out.println("yes");
					
		}
		else
		{System.out.println("no");}
		
		System.out.println(p2.inventoryToString());
		
		Map map = new Map();
		
		System.out.println(map.mapToString());
		HashMap<Room,String> moves = new HashMap<Room,String>();
		moves = map.bossMove();
		
		String moveString ="";
		moveString+="Boss can reach player by going...\n"
				+"...";
		
		for (Room i : moves.keySet())
		{
			moveString+=(moves.get(i)+"\n");
		}
		
		System.out.println(moveString);
//
//		System.out.println(p2.getInventory().get(i2).getCoordY());

		
//		System.out.println(p2.getInventory().containsKey("Head"));
//		System.out.println(p2.getInventory().get("Head"));

		
		
		// TODO Auto-generated method stub
		
//		Coordinate coord = new Coordinate(0,1);
//		
//		System.out.println("("+coord.getCoordX()+","+coord.getCoordY()+")");
//		
//		// TODO Auto-generated method stub
//		Scanner input = new Scanner(System.in);
//		
//		int MAX_PLAYER_TURNS = 3;
//		int turns = MAX_PLAYER_TURNS;
//		
//		Player p1 = new Player();
//		Map map = new Map();
//		
//		ArrayList<String> validCommands = new ArrayList<String>();
//		validCommands.add("scan");
//		validCommands.add("diagnostic");
//		validCommands.add("move");
//		validCommands.add("collect");
//		validCommands.add("wait");
//		validCommands.add("exit");
//		
////		String choice = "";
//		boolean quitGame = false;
//		
//		System.out.println(map.mapToString());//dbg FIXME
//		
//		while (!quitGame)
//		{
//			System.out.println(map.mapToString());//dbg FIXME
//			if (turns<=0)
//			{
//				map.moveBoss();
//				turns = MAX_PLAYER_TURNS;
//			}
//			
//			if (map.locatePlayer().isBossHere() == true)
//			{
//				System.out.println("Bolbi and Furnace-Face are about to face off!");
//				int itemsAcquired = 0;
//				for (int i = 0; i < p1.getItemTotal(); i++)
//				{
//					if (p1.getInventory().get(i).isItemTaken())
//					{
//						itemsAcquired++;
//					}
//				}
//				if (itemsAcquired == p1.getItemTotal())
//				{
//					System.out.println("Bolbi was ready to fight off Furnace-Face! He unscrewed the bolts "
//							+ "from the mechanical menace and watched the heavy machine parts collapse into a scrap heap.");
//					System.out.println("You have won the game, Congratulations!");
//				}
//				else
//				{
//					System.out.println("Bolbi was not prepared to fight. Furnace-Face was easily able to crush him and melt him down for scrap...");
//					
////					System.out.println(p1.inventoryToString());
//				
//					System.out.println("Player collected " + itemsAcquired
//							+ " out of " + p1.getItemTotal()+ ", and it was not enough. Try again!");
//				}
////			choice = "exit";
//			quitGame = true;
//			break;
//			}
//			String playerCommand = "";
//			while (!playerCommand.equals("exit")
//					&& !playerCommand.equals("scan")
//					&& !playerCommand.equals("diagnostic")
//					&& !playerCommand.equals("move")
//					&& !playerCommand.equals("collect")
//					&& !playerCommand.equals("wait")
//					&& !playerCommand.equals("exit")
//					)
//			{
//				System.out.println("OPTIONS: scan, diagnostic, move, collect, wait, exit");
//				playerCommand = input.nextLine();
//				
//				if (!validCommands.contains(playerCommand))
//				{
//					System.out.println("invalid command");
//				}
//			}
//				
//				if (playerCommand.equals("exit"))
//				{
////					choice = "exit";
//					quitGame = true;
//					continue;
//				}
//				else if (playerCommand.equals("scan"))
//				{
//					Room playerRoom = map.locatePlayer();
//					System.out.println("Surrounded by " + playerRoom.getRoomName());
//					System.out.println(playerRoom.getRoomItem() + " is here!");
//					System.out.println("Bolbi senses Furnace-Face is... "+map.whereBossAdjacent());
//					
//				}
//				else if (playerCommand.equals("move"))
//				{
//					String direction = "";
//					ArrayList<String> directions = new ArrayList<String>();
//					directions.add("North");
//					directions.add("South");
//					directions.add("East");
//					directions.add("West");
//					
//					
////					while(!direction.equals("North")
////							&& !direction.equals("South")
////							&& !direction.equals("East")
////							&& !direction.equals("West")
////							)
//					while(!directions.contains(direction))
//					{
//						System.out.println("You can move ");
////						String move_options = map.getValidMoves().get(0);
//						System.out.print(map.getValidMoves().get(0)+" ");
//						for(int i = 1; i < map.getValidMoves().size(); i++)
//						{
//							System.out.print("or " + map.getValidMoves().get(i) + " ");
//						}	
//						System.out.println("");
//						
//						direction = input.nextLine();
//						
//						if(!directions.contains(direction))
//						{
//							System.out.println("invalid direction");
//						}
//						
//						if(!map.getValidMoves().contains(direction))
//						{
//							System.out.println("can't go that way");
//							direction = "";
//						}
//						
//					}
//					System.out.println("Bolbi gets moving... \n");
//					map.movePlayer(direction);
//					System.out.println("Bolbi is now in " + map.locatePlayer().getRoomName());
//					turns-=1;
//				}
//				else if (playerCommand.equals("diagnostic"))
//				{
//					System.out.println(p1.inventoryToString());
//				}
//				else if (playerCommand.equals("collect"))
//				{
//					
////					p1.getInventory().get(i).isItemTaken()
//					Room playerRoom = map.locatePlayer();	//retrieve Room and store in playerRoom var
//					System.out.println("Room" + map.locatePlayer().getRoomName());
//					String itemName = playerRoom.getRoomItem();	//copy name of item of room player's in into itemName
//					System.out.println("Item in room is " + itemName);
//					int itemIndex = p1.getInventory().indexOf(itemName);	// FIXME why is this negative 1? leads out of bounds
//					System.out.println("Which is in index " +itemIndex + " of player inventory.");
//					Item toTake = p1.getItemByName(itemName);
////					int itemIndex = p1.getInventory().indexOf(itemName);	// FIXME why is this negative 1? leads out of bounds
////					p1.getInventory().get(itemIndex).setItemTaken(true);
//					if (playerRoom.getRoomItem()!=null)
//					{
//						toTake.setItemTaken(true);
//						playerRoom.setRoomItem(null);
//						turns-=1;
//					}
//					else
//					{
//						System.out.println("Nothing to take here, no action taken.");
//					}
////					.setItemTaken(true);
////					p1.getInventory().get(turns).setItemTaken(true);
//					
//				}
//				else if (playerCommand.equals("wait"))
//				{
//					turns-=1;
//				}
//
//			}
//			
//			
//		}	//end gameplay loop
//
//			
		}
		
		
		
	
	

		
		

	}




